package codegeneration;

public record DtoBytes (
    int bytesReturn,
     int bytesLocals,
     int bytesParams){}
//
//
//    public DtoBytes(int bytesReturn, int bytesLocals, int bytesParams) {
//        this.bytesReturn = bytesReturn;
//        this.bytesLocals = bytesLocals;
//        this.bytesParams = bytesParams;
//    }
//
//    public int getBytesReturn() {
//        return bytesReturn;
//    }
//
//    public void setBytesReturn(int bytesReturn) {
//        this.bytesReturn = bytesReturn;
//    }
//
//    public int getBytesLocals() {
//        return bytesLocals;
//    }
//
//    public void setBytesLocals(int bytesLocals) {
//        this.bytesLocals = bytesLocals;
//    }
//
//    public int getBytesParams() {
//        return bytesParams;
//    }
//
//    public void setBytesParams(int bytesParams) {
//        this.bytesParams = bytesParams;
//    }

