package ast.statements;

import ast.Locatable;

public interface Statement extends Locatable {
}
