package ast.type;

public class VoidType implements Type {
}
