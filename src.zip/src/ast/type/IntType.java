package ast.type;

public class IntType implements Type {
}
