package ast.type;

public class CharType implements Type{
}
