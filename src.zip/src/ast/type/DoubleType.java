package ast.type;

public class DoubleType implements Type{

}
